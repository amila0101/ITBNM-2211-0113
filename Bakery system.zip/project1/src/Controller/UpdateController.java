

package Controller;

import Model.DBSearch;
import Model.DBUpdate;
import View.customers;
import View.orderdetails;
import View.orders;
import View.products;
import View.users;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;



public class UpdateController {
    
   public void UpdateCustomer(String id, String name,  int contact_number, String email){
        if(id.equals("") || name.equals("") || contact_number==00 || email.equals("")){
            JOptionPane.showMessageDialog(null,"Not Update");
        }
        else {
            new DBUpdate().UpdateCustomer(id,name,contact_number,email);
            JOptionPane.showMessageDialog(null, "Updated");
        }
    }
   
   
    public void UpdateUsers(String id, String username, String password, String role){
        if(id.equals("") || username.equals("") || password.equals("") || role.equals("")){
            JOptionPane.showMessageDialog(null,"Not Update");
        }
        else {
            new DBUpdate().UpdateUsers(id,username,password,role);
            JOptionPane.showMessageDialog(null, "Updated");
        }
    }
    
    public void UpdatProducts(String id, String name,  String category, double price, int quantity){
        if(id.equals("") || name.equals("") || category.equals("") || price==0.0 || quantity==00){
            JOptionPane.showMessageDialog(null,"Not Update");
        }
        else {
            new DBUpdate().UpdateProducts(id,name,category,price,quantity);
            JOptionPane.showMessageDialog(null, "Updated");
        }
    }
    
    public void UpdateOrders(String id, String customer_id,  String date, double amount){
        if(id.equals("") || customer_id.equals("") || date.equals("") || amount==0.0) {
            JOptionPane.showMessageDialog(null,"Not Update");
        }
        else {
            new DBUpdate().UpdateOrders(id,customer_id,date,amount);
            JOptionPane.showMessageDialog(null, "Updated");
        }
    }
    
    
    public void UpdateOrderDetails(String order_detail_id, String order_id, String product_id, int quantity, double price){
        if(order_detail_id.equals("") || order_id.equals("") || product_id.equals("") || quantity==00 || price==0.0) {
            JOptionPane.showMessageDialog(null,"Not Update");
        }
        else {
            new DBUpdate().UpdateOrderDetails(order_detail_id,order_id,product_id,quantity,price);
            JOptionPane.showMessageDialog(null, "Updated");
        }
    }
    
   
    // all table data loading
    public void updateUsersTable(JTable table1) {
    try {
        ResultSet rs = null;
        
        DefaultTableModel tb1 = (DefaultTableModel) table1.getModel();
        tb1.setRowCount(0);
        
        rs = new DBSearch().SearchAllUsers();
        
        while (rs.next()) {
            String id = rs.getString("id");
            String username = rs.getString("username");
            String password = rs.getString("password");
            String role = rs.getString("role");
            
            String tbData[] = {id, username, password, role};
            tb1.addRow(tbData);
        }
    } catch (SQLException ex) {
        Logger.getLogger(UpdateController.class.getName()).log(Level.SEVERE, null, ex);
    }
    
}

    public void updateCustomersTable(JTable table2) {
    try {
        ResultSet rs = null;
        
        DefaultTableModel tb1 = (DefaultTableModel) table2.getModel();
        tb1.setRowCount(0);
        
        rs = new DBSearch().SearchAllCustomers(); 
        
        while (rs.next()) {
            String id = rs.getString("id");
            String name = rs.getString("name");
            String contact_number = rs.getString("contact_number");
            String email = rs.getString("email");
            
            String tbData[] = {id, name, contact_number, email};
            tb1.addRow(tbData);
        }
    } catch (SQLException ex) {
        Logger.getLogger(UpdateController.class.getName()).log(Level.SEVERE, null, ex);
    }
}

     
        public void updatProductsTable(JTable table3) {
    try {
        ResultSet rs = null;
        
        DefaultTableModel tb1 = (DefaultTableModel) table3.getModel();
        tb1.setRowCount(0);
        
        rs = new DBSearch().SearchAllProducts();
        
        while (rs.next()) {
            String id = rs.getString("id");
              String name = rs.getString("name");
              String category = rs.getString("category");
              String price = rs.getString("price");
              String quantity = rs.getString("quantity");
            
            String tbData[] = {id, name, category, price, quantity};
            tb1.addRow(tbData);
        }
    } catch (SQLException ex) {
        Logger.getLogger(UpdateController.class.getName()).log(Level.SEVERE, null, ex);
    }
}
       
       public void updatOrdersTable(JTable table4) {
    try {
        ResultSet rs = null;
        
        DefaultTableModel tb1 = (DefaultTableModel) table4.getModel();
        tb1.setRowCount(0);
        
        rs = new DBSearch().SearchAllOrders();
        
        while (rs.next()) {
            String id = rs.getString("id");
            String customer_id = rs.getString("customer_id");
            String date = rs.getString("date");
            String amount  = rs.getString("amount");
            
            String tbData[] = {id, customer_id, date, amount};
            tb1.addRow(tbData);
        }
    } catch (SQLException ex) {
        Logger.getLogger(UpdateController.class.getName()).log(Level.SEVERE, null, ex);
    }
}
       public void  updateOrderDetailsTable(JTable table5) {
    try {
        ResultSet rs = null;
        
        DefaultTableModel tb1 = (DefaultTableModel) table5.getModel();
        tb1.setRowCount(0);
        
        rs = new DBSearch().SearchAllOrderDetails();
        
        while (rs.next()) {
            String order_detail_id  = rs.getString("order_detail_id");
            String  order_id  = rs.getString("order_id");
            String  product_id  = rs.getString("product_id");
            String  quantity  = rs.getString("quantity");
            String  price = rs.getString("price");
            
            String tbData[] = {order_detail_id, order_id, product_id, quantity, price};
            tb1.addRow(tbData);
        }
    } catch (SQLException ex) {
        Logger.getLogger(UpdateController.class.getName()).log(Level.SEVERE, null, ex);
    }
}  
          
       
   // clear button
      public void CustomersClear(){
       customers cus =  new customers();
       cus.idbox1.setText("");
       cus.namebox1.setText("");
       cus.contactnumberbox1.setText("");
       cus.emailbox.setText("");
       cus.searchbox1.setText("");
}
     
      public void  UsersClear(){
          users cus = new users();
          cus.idbox.setText("");
          cus.unsernamebox.setText("");
          cus.passwordbox.setText("");
          cus.rolebox.setText("");
          cus.searchbox.setText("");
      }
       
        public void  ProductsClear(){
          products cus = new  products();
          cus.idbox2.setText("");
          cus.namebox2.setText("");
          cus.categorybox.setSelectedItem("");
          cus.pricebox.setText("");
          cus.quantitybox.setText("");
          cus.searchbox2.setText("");
      }
       
        public void OrdersClear() {
            orders cus = new orders();
            cus.idbox3.setText("");
            cus.cidbox.setText("");
            cus.datebox.setText("");
            cus.amountbox.setText("");
            cus.searchbox3.setText("");
    }
        
        public void OrderDetailsClear(){
            orderdetails cus = new orderdetails();
            cus.odidbox.setText("");
            cus.oidbox.setText("");
            cus.pidbox.setText("");
            cus.quantitybox1.setText("");
            cus.pricebox1.setText("");
            cus.searchbox4.setText("");
            
        }
        
        
        
}

